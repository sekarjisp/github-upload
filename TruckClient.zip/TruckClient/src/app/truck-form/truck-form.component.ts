import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TruckService } from '../service/truck.service';
import { Truck } from '../model/truck';

@Component({
  selector: 'app-truck-form',
  templateUrl: './truck-form.component.html',
  styleUrls: ['./truck-form.component.css']
})
export class TruckFormComponent  {
	truck: Truck;

  constructor(private route: ActivatedRoute,private router: Router, private truckService: TruckService)
  {
    this.truck = new Truck();
	}

   onSubmit() {
    this.truckService.save(this.truck).subscribe(result => this.gotoTruckList());
  }

  gotoTruckList() {
    this.router.navigate(['/trucks']);
  }

}

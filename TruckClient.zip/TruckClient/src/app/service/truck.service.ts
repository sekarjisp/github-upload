import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Truck } from '../model/truck';
import { Observable } from 'rxjs/Observable';

@Injectable({
  providedIn: 'root'
})
export class TruckService {
private truckUrl: string;
  constructor(private http: HttpClient) {
    this.truckUrl = 'http://localhost:8080/trucks';
  }
  
  public findAll(): Observable<Truck[]> {
    return this.http.get<Truck[]>(this.truckUrl);
  }

  public save(truck: Truck) {
    return this.http.post<Truck>(this.truckUrl, truck);
  }
  
}

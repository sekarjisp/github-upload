import { Truck } from './truck';

describe('Truck', () => {
  it('should create an instance', () => {
    expect(new Truck()).toBeTruthy();
  });
});

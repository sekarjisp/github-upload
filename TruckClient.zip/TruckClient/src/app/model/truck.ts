export class Truck {
	id: string = "";
    name: string = "";
    destination: string = "";
}

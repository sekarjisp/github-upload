import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TruckListComponent } from './truck-list/truck-list.component';
import { TruckFormComponent } from './truck-form/truck-form.component';
const routes: Routes = [
  { path: 'trucks', component: TruckListComponent },
  { path: 'addTruck', component: TruckFormComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

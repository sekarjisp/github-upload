import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { TruckListComponent } from './truck-list/truck-list.component';
import { TruckFormComponent } from './truck-form/truck-form.component';
import { TruckService } from './service/truck.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // <== add the imports!
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    TruckListComponent,
    TruckFormComponent
  ],
  imports: [
  	 HttpClientModule,	   
    BrowserModule,
    AppRoutingModule,
	FormsModule,                               // <========== Add this line!
    ReactiveFormsModule   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

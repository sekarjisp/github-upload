export class User {
	id: string = 1;
    name: string = "name";
    email: string = "dest";
}

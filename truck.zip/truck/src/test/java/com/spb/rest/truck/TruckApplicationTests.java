package com.spb.rest.truck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruckApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.spb.rest.truck;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Truck {
    
    @Override
	public String toString() {
		return "Truck [id=" + id + ", name=" + name + ", destination=" + destination + "]";
	}

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private final String name;
    private final String destination;
    
    public Truck() {
        this.name = "";
        this.destination = "";
    }
    
    public Truck(String name, String email) {
        this.name = name;
        this.destination = email;
    }

    public long getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }

	public String getDestination() {
		return destination;
	}

   
}

package com.spb.rest.truck;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TruckController {

	private final TruckRepository   truckRepository;

	public TruckController(TruckRepository truckRepository) {
		this.truckRepository = truckRepository;
	}

	@GetMapping("/trucks")
	public List<Truck> getTrucks() {
		return (List<Truck>) truckRepository.findAll();
	}

	@PostMapping("/trucks")
	void addTruck(@RequestBody Truck truckr) {
		truckRepository.save(truckr);
	}
}

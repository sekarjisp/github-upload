package com.spb.rest.truck;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TruckApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruckApplication.class, args);
	}

	@Bean
	CommandLineRunner init(TruckRepository truckRepository) {
		List trucks = new ArrayList();
		Truck truck = new Truck("Freightliner", "Newyork");
		trucks.add(truck);
		truckRepository.save(truck);
		truck = new Truck("Kenworth", "Chicago");
		trucks.add(truck);
		truckRepository.save(truck);
		truck = new Truck("Peterbilt", "Houston");
		trucks.add(truck);
		truckRepository.save(truck);
		truck = new Truck("Volvo", "Los Angeles");
		trucks.add(truck);
		truckRepository.save(truck);
	     return args -> {
	   
		truckRepository.findAll().forEach(System.out::println);
	     };

	}

}
